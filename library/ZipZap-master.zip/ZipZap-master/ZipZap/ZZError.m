//
//  ZZError.m
//  ZipZap
//
//  Created by Glen Low on 25/01/13.
//  Copyright (c) 2013, Pixelglow Software. All rights reserved.
//

#import "ZZError.h"

NSString* const ZZErrorDomain = @"com.pixelglow.ZipZap";

NSString* const ZZEntryIndexKey = @"ZZEntryIndexKey";
