//
//  main.m
//  HudDemo
//
//  Created by Matej Bukovinski on 2.4.09.
//  Copyright bukovinski.com 2009-2015. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBHudDemoAppDelegate.h"

int main(int argc, char *argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MBHudDemoAppDelegate class]));
    }
}
